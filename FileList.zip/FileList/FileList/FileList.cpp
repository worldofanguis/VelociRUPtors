// FileList.cpp : Defines the entry point for the console application.
//

#undef UNICODE
#include "stdafx.h"


int main(int argc, char* argv[])
{
	WIN32_FIND_DATA FData;
	HANDLE hFile = FindFirstFile("*.*",&FData);
	FILE* FKez;
	
	fopen_s(&FKez,"Dirlist.txt","w");
	
	SYSTEMTIME sTime;
	while(hFile != INVALID_HANDLE_VALUE)
		{
		if((FData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY)
			{
			FileTimeToSystemTime(&FData.ftCreationTime,&sTime);
			fprintf_s(FKez,"%s;%d;%d.%d.%d\n",FData.cFileName,FData.nFileSizeLow,sTime.wYear,sTime.wMonth,sTime.wDay);
			}
		if(!FindNextFile(hFile,&FData))
			break;
		}

	FindClose(hFile);
	fclose(FKez);
return 0;
}

